
package banco1;

public class ContaBancaria {
    
    // numero sequencial para cada nova conta
    private static long numero = 1;
    
    private long numeroConta;
    private String titular;
    private double saldo;

    public ContaBancaria() {
        numeroConta = numero;
        numero += 1;
        this.titular = "";
        this.saldo = 0.0;
    }

    public ContaBancaria(String titular, double saldo) {
        numeroConta = numero;
        numero += 1;
        this.titular = titular;
        if( saldo > 0 )
            this.saldo = saldo;
    }

    public static long getNumero() {
        return numero;
    }

    public static void setNumero(long numero) {
        ContaBancaria.numero = numero;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        if( saldo > 0 )
            this.saldo = saldo;
    }
    
    public void depositar( double montante ){
        saldo += montante;
    }
    
    public void levantar( double montante ){
        if( saldo - montante >= 0 )
            saldo -= montante;
        else
            System.out.println("Nao existe saldo suficiente.");
    }
    
    @Override
    public String toString(){
        return "Conta " + numeroConta + ", " + titular + ", " + saldo ;
    }
}
