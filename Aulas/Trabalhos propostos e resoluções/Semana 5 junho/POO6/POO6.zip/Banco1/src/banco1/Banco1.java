
package banco1;

public class Banco1 {
    
    public static void main(String[] args) {
       
        ContaBancaria c1 = new ContaBancaria();
        ContaBancaria c2 = new ContaBancaria( "Antonio Santos", 1000 );
        
        System.out.println(c1);
        System.out.println(c2);
        
        c1.setTitular("Maria Silva");
        c1.setSaldo(2000);
        
        c1.depositar(100);
        System.out.println(c1.getSaldo());
        
        c1.levantar(20);
        System.out.println(c1.getSaldo());
        
        ContaBancaria c3 = new ContaBancaria( "Manuel Sousa", 500 );
        
        System.out.println(c1);
        System.out.println(c2);
        System.out.println(c3);   
    }
}
