
package fazcalculos;

public class Calculadora {
    
    public Calculadora() {}
    
    public double soma( double x, double y ){
        return x + y;
    }
    
    public double subtrai( double x, double y ){
        return x - y;
    }
     
    public double multiplica( double x, double y ){
        return x * y;
    }
      
    public double divide( double x, double y ){
        return x / y;
    }
}
