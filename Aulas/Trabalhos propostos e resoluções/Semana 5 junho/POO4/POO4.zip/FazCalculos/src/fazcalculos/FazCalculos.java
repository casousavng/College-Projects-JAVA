
package fazcalculos;

import java.util.Scanner;

public class FazCalculos {

    public static void main(String[] args) {
        
        Scanner leia = new Scanner( System.in );
        
        Calculadora c = new Calculadora();
        
        System.out.println("Soma: " + c.soma( 2.7, 5.2));
        System.out.println("Subtracao: " + c.subtrai( 2.7, 5.2));
        System.out.println("Multiplicacao: " + c.multiplica( 2.7, 5.2));
        System.out.println("Divisao: " + c.divide( 2.7, 5.2));
        
        System.out.print("Insira o primeiro operando: ");
        double x = leia.nextDouble();
        System.out.print("Insira o segundo operando: ");
        double y = leia.nextDouble();
        
        System.out.println("Soma: " + c.soma( x, y));
        System.out.println("Subtracao: " + c.subtrai( x, y));
        System.out.println("Multiplicacao: " + c.multiplica( x, y));
        System.out.println("Divisao: " + c.divide( x, y));
    }
    
}
