/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo1;

/**
 *
 * @author andresousa
 */
class Retangulo {
    
    private double x1, y1, x2, y2;

    public Retangulo() {
        // Construtor sem parâmetros
    }

    public Retangulo(double x1, double y1, double x2, double y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    public double calcularBase() {
        return Math.abs(x2 - x1);
    }

    public double calcularAltura() {
        return Math.abs(y2 - y1);
    }

    public double calcularPerimetro() {
        double base = calcularBase();
        double altura = calcularAltura();
        return 2 * base + 2 * altura;
    }

    public double calcularArea() {
        double base = calcularBase();
        double altura = calcularAltura();
        return base * altura;
    }
}
