/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo1;

/**
 *
 * @author andresousa
 */
class ConstroiRetangulo {
    
    public void calcularMedidas() {
        
        Retangulo retangulo = new Retangulo(2.0, 1.0, 4.0, 5.0);
        
        double base = retangulo.calcularBase();
        double altura = retangulo.calcularAltura();
        double perimetro = retangulo.calcularPerimetro();
        double area = retangulo.calcularArea();

        System.out.println("Base: " + base);
        System.out.println("Altura: " + altura);
        System.out.println("Perímetro: " + perimetro);
        System.out.println("Área: " + area);
    }
}