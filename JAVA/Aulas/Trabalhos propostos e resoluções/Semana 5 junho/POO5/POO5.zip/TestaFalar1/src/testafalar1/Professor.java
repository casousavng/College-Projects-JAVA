
package testafalar1;

public class Professor extends Pessoa {
    private String grupo;
    private int escalao;

    public Professor() {
        this.grupo = "";
        this.escalao = 1;
    }
    
    public Professor(String nome, char genero, int idade, String grupo, int escalao) {
        super( nome, genero, idade );
        this.grupo = grupo;
        this.escalao = escalao;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public int getEscalao() {
        return escalao;
    }

    public void setEscalao(int escalao) {
        this.escalao = escalao;
    }
    
    public void falar( String s ){
        super.falar( s );
    }
    
    public void falar(){
        super.falar();
        System.out.println( "e sou um professsor");
    }
}
