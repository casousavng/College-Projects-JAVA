
package testafalar1;


public class Aluno extends Pessoa {
    private int numero;
    private String turma;

    public Aluno() {
        super();
        this.numero = 0;
        this.turma = "";
    }

    public Aluno(String nome, char genero, int idade, int numero, String turma) {
        super( nome, genero, idade );
        this.numero = numero;
        this.turma = turma;
    }
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getTurma() {
        return turma;
    }

    public void setTurma(String turma) {
        this.turma = turma;
    }
     
  
    
    @Override
    public void falar(){
        super.falar();
        System.out.println( "e sou um aluno");
    }
    
    public void falar( String s ){
        super.falar( s );
    }
    
    @Override
    public String toString(){
        return super.toString() + numero + ":" + turma;
    }
   
}
