
package testafalar1;

public class TestaFalar1 {

    public static void main(String[] args) {
       
        Aluno a = new Aluno();
        Professor p = new Professor();
        
        a.falar();
        p.falar();
         
        Aluno a1 = new Aluno( "Pedro Martins", 'M', 15, 23, "A");
        Professor p1 = new Professor( "Helena Lopes", 'F', 40, "550", 2 );
        
        // Mostra o nome, genero e idade de a1
        System.out.println("Nome   : " + a1.getNome() );
        System.out.println("Genero : " + a1.getGenero() );
        System.out.println("Idade  : " + a1.getIdade() );
        
        // Mostra o numero e a turma de a1
        System.out.println("Grupo  : " + a1.getNumero() );
        System.out.println("Escalao: " + a1.getTurma() );
        
         // Mostra o nome, genero e idade de p1
        System.out.println("Nome   : " + p1.getNome() );
        System.out.println("Genero : " + p1.getGenero() );
        System.out.println("Idade  : " + p1.getIdade() );
        
        // Mostra o grupo de docencia e o escalao de p1
        System.out.println("Grupo  : " + p1.getGrupo() );
        System.out.println("Escalao: " + p1.getEscalao() );
        
        a1.falar( "Isto é um aluno a falar ...");
        
        Professor p2 = new Professor();
        
        p2.setNome("Luis");
        p2.setGenero('M');
        p2.setIdade(30);
        
        System.out.println(p2);
       
        p2.falar();
    }
    
}
