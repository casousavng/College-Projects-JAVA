
package testafalar1;

public class Pessoa {
    private String nome;
    private char genero;
    private int idade;

    public Pessoa(){
        nome = "";
        genero = ' ';
        idade = 18;
    }

    public Pessoa( String nome, char genero ){
        this.nome = nome;
        this.genero = genero;
    }

    public Pessoa( String nome, char genero, int idade ){
        this.nome = nome;
        this.genero = genero;
        this.idade = idade;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public char getGenero() {
        return genero;
    }

    public void setGenero(char genero) {
        this.genero = genero;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        if( idade >= 18 )
            this.idade = idade;
        else
            this.idade = 18;
    }
    
    // sobrecarga - overload
    // numa classe podem existir métodos com o mesmo nome
    // desde que tenham assinaturas diferentes
    public void falar(){
        System.out.println( "Sou uma pessoa");
    }

    public void falar( String s ){
        System.out.println( s );
    }
    
    // sobreposição - override
    @Override
    public String toString(){
        return "" + nome + ":" + genero + ":" + idade;
    }
    
}
